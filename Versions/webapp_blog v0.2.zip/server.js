const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = 3000;

const USERS_FILE = path.join(__dirname, 'database', 'users.json');
const POSTS_FILE = path.join(__dirname, 'database', 'posts.json');
const COMMENTS_FILE = path.join(__dirname, 'database', 'comments.json');
const { randomUUID } = require('crypto');

function readJSON(filePath) {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}
function writeJSON(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}
// *********************************************************************************************
// Users CRUD
// Cadastro
app.post('/users', (req, res) => {
    const { name, username, email, password } = req.body;
    if (!name || !username || !email || !password) {
        return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    const users = readJSON(USERS_FILE);
    if (users.find(u => u.username === username)) {
        return res.status(409).json({ error: 'Nome de usuário já existe' });
    } else if (users.find(u => u.email === email)) {
        return res.status(409).json({ error: 'Endereço de email já existe' });
    } else if (password.length < 6) {
        return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres' });
    }

    const newUser = { id: randomUUID(), name, username, email, password };

    users.push(newUser);
    writeJSON(USERS_FILE, users);
    res.status(201).json({message: `Seu cadastro foi realizado com sucesso!`, user: { id, name, username, email }});
});

// Listagem
app.get('/users', (req, res) => {
    const users = readJSON(USERS_FILE);
    const sanitized = users.map(u => ({id: u.id, name: u.name, username: u.username, email: u.email}));
    res.json(sanitized);
});

// Atualizar cadastro
app.put('/users/:id', (req, res) => {
    const users = readJSON(USERS_FILE);
    const { id } = req.params;
    const { name, username, email, password } = req.body;
    const usersIndex = users.findIndex(u => u.id == id);
    if (usersIndex === -1) {
        return res.status(404).json({ error: 'Usuário não encontrado.' });
    }

    if (name !== undefined && name === "") {
        return res.status(404).json({ error: "Nome não pode ser vazio" });
    }

    users[usersIndex] = { ...users[usersIndex], name, username, email, password };
    writeJSON(USERS_FILE, users);
    res.json({ message: 'Usuário atualizado com sucesso.' });
});

// Deletar cadastro
app.delete('/users/:id', (req, res) => {
    const users = readJSON(USERS_FILE);
    const { id } = req.params;

    const index = users.findIndex(u => u.id === id);
    if (index === -1) {
        return res.status(404).json({ error: 'Usuário não encontrado.' });
    }

    users.splice(index, 1);
    writeJSON(USERS_FILE, users);

    res.json({message: "Usuário deletado com sucesso."});
});
// *********************************************************************************************
// Posts CRUD

// *********************************************************************************************
// Comments CRUD

// *********************************************************************************************
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});